from web3 import Web3

# Connect to an Ethereum node (e.g., Infura)
web3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/your_infura_project_id'))

# Contract ABI (example ABI of an ERC20 token contract)
contract_abi = [
    # ... (Add the ABI entries here)
]

# Contract address (example ERC20 token contract address)
contract_address = '0x123abc...'

# Set the contract instance
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

# Example interaction with the contract (get token name)
def get_token_name():
    token_name = contract.functions.name().call()
    return token_name

# Example interaction with the contract (get token balance)
def get_token_balance(account_address):
    balance = contract.functions.balanceOf(account_address).call()
    return balance

# Example transaction to transfer tokens
def transfer_tokens(sender_private_key, receiver_address, amount):
    sender_account = web3.eth.account.privateKeyToAccount(sender_private_key)
    transaction = contract.functions.transfer(receiver_address, amount).buildTransaction({
        'from': sender_account.address,
        'gas': 2000000,
        'gasPrice': web3.toWei('50', 'gwei'),
        'nonce': web3.eth.getTransactionCount(sender_account.address),
    })
    signed_txn = web3.eth.account.signTransaction(transaction, sender_private_key)
    tx_hash = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    return tx_hash.hex()

# Example usage
if __name__ == "__main__":
    # Replace 'your_private_key' and 'receiver_address' with appropriate values
    private_key = 'your_private_key_here'
    receiver_address = '0xabc123...'
    amount_to_send = 100

    token_name = get_token_name()
    print(f'Token Name: {token_name}')

    balance = get_token_balance('your_account_address_here')
    print(f'Your Token Balance: {balance}')

    tx_hash = transfer_tokens(private_key, receiver_address, amount_to_send)
    print(f'Transaction Hash: {tx_hash}')
from web3 import Web3

# Connect to an Ethereum node (e.g., Infura)
web3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/your_infura_project_id'))

# Contract ABI (example ABI of an ERC20 token contract)
contract_abi = [
    # ... (Add the ABI entries here)
]

# Contract address (example ERC20 token contract address)
contract_address = '0x123abc...'

# Set the contract instance
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

# Example interaction with the contract (get token name)
def get_token_name():
    token_name = contract.functions.name().call()
    return token_name

# Example interaction with the contract (get token symbol)
def get_token_symbol():
    token_symbol = contract.functions.symbol().call()
    return token_symbol

# Example interaction with the contract (get token decimals)
def get_token_decimals():
    token_decimals = contract.functions.decimals().call()
    return token_decimals

# Example interaction with the contract (get token total supply)
def get_token_total_supply():
    total_supply = contract.functions.totalSupply().call()
    return total_supply

# Example interaction with the contract (get balance of an address)
def get_token_balance(account_address):
    balance = contract.functions.balanceOf(account_address).call()
    return balance

# Example transaction to transfer tokens
def transfer_tokens(sender_private_key, receiver_address, amount):
    sender_account = web3.eth.account.privateKeyToAccount(sender_private_key)
    transaction = contract.functions.transfer(receiver_address, amount).buildTransaction({
        'from': sender_account.address,
        'gas': 2000000,
        'gasPrice': web3.toWei('50', 'gwei'),
        'nonce': web3.eth.getTransactionCount(sender_account.address),
    })
    signed_txn = web3.eth.account.signTransaction(transaction, sender_private_key)
    tx_hash = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    return tx_hash.hex()

# Example usage
if __name__ == "__main__":
    # Replace 'your_private_key' and 'receiver_address' with appropriate values
    private_key = 'your_private_key_here'
    receiver_address = '0xabc123...'
    amount_to_send = 100

    token_name = get_token_name()
    print(f'Token Name: {token_name}')

    token_symbol = get_token_symbol()
    print(f'Token Symbol: {token_symbol}')

    token_decimals = get_token_decimals()
    print(f'Token Decimals: {token_decimals}')

    total_supply = get_token_total_supply()
    print(f'Total Token Supply: {total_supply}')

    balance = get_token_balance('your_account_address_here')
    print(f'Your Token Balance: {balance}')

    tx_hash = transfer_tokens(private_key, receiver_address, amount_to_send)
    print(f'Transaction Hash: {tx_hash}')
from web3 import Web3

# Connect to an Ethereum node (e.g., Infura)
web3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/your_infura_project_id'))

# Contract ABI (example ABI of an ERC20 token contract)
contract_abi = [
    # ... (Add the ABI entries here)
]

# Contract address (example ERC20 token contract address)
contract_address = '0x123abc...'

# Set the contract instance
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

# Example interaction with the contract (get token name)
def get_token_name():
    token_name = contract.functions.name().call()
    return token_name

# Example interaction with the contract (get token symbol)
def get_token_symbol():
    token_symbol = contract.functions.symbol().call()
    return token_symbol

# Example interaction with the contract (get token decimals)
def get_token_decimals():
    token_decimals = contract.functions.decimals().call()
    return token_decimals

# Example interaction with the contract (get token total supply)
def get_token_total_supply():
    total_supply = contract.functions.totalSupply().call()
    return total_supply

# Example interaction with the contract (get balance of an address)
def get_token_balance(account_address):
    balance = contract.functions.balanceOf(account_address).call()
    return balance

# Example transaction to transfer tokens
def transfer_tokens(sender_private_key, receiver_address, amount):
    sender_account = web3.eth.account.privateKeyToAccount(sender_private_key)
    transaction = contract.functions.transfer(receiver_address, amount).buildTransaction({
        'from': sender_account.address,
        'gas': 2000000,
        'gasPrice': web3.toWei('50', 'gwei'),
        'nonce': web3.eth.getTransactionCount(sender_account.address),
    })
    signed_txn = web3.eth.account.signTransaction(transaction, sender_private_key)
    tx_hash = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    return tx_hash.hex()

# Example usage
if __name__ == "__main__":
    # Replace 'your_private_key' and 'receiver_address' with appropriate values
    private_key = 'your_private_key_here'
    receiver_address = '0xabc123...'
    amount_to_send = 100

    token_name = get_token_name()
    print(f'Token Name: {token_name}')

    token_symbol = get_token_symbol()
    print(f'Token Symbol: {token_symbol}')

    token_decimals = get_token_decimals()
    print(f'Token Decimals: {token_decimals}')

    total_supply = get_token_total_supply()
    print(f'Total Token Supply: {total_supply}')

    balance = get_token_balance('your_account_address_here')
    print(f'Your Token Balance: {balance}')

    tx_hash = transfer_tokens(private_key, receiver_address, amount_to_send)
    print(f'Transaction Hash: {tx_hash}')
from web3 import Web3

# Connect to an Ethereum node (e.g., Infura)
web3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/your_infura_project_id'))

# Contract ABI (example ABI of an ERC20 token contract)
contract_abi = [
    # ... (Add the ABI entries here)
]

# Contract address (example ERC20 token contract address)
contract_address = '0x123abc...'

# Set the contract instance
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

# Example interaction with the contract (get token name)
def get_token_name():
    token_name = contract.functions.name().call()
    return token_name

# Example interaction with the contract (get token symbol)
def get_token_symbol():
    token_symbol = contract.functions.symbol().call()
    return token_symbol

# Example interaction with the contract (get token decimals)
def get_token_decimals():
    token_decimals = contract.functions.decimals().call()
    return token_decimals

# Example interaction with the contract (get token total supply)
def get_token_total_supply():
    total_supply = contract.functions.totalSupply().call()
    return total_supply

# Example interaction with the contract (get balance of an address)
def get_token_balance(account_address):
    balance = contract.functions.balanceOf(account_address).call()
    return balance

# Example transaction to transfer tokens
def transfer_tokens(sender_private_key, receiver_address, amount):
    sender_account = web3.eth.account.privateKeyToAccount(sender_private_key)
    transaction = contract.functions.transfer(receiver_address, amount).buildTransaction({
        'from': sender_account.address,
        'gas': 2000000,
        'gasPrice': web3.toWei('50', 'gwei'),
        'nonce': web3.eth.getTransactionCount(sender_account.address),
    })
    signed_txn = web3.eth.account.signTransaction(transaction, sender_private_key)
    tx_hash = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    return tx_hash.hex()

# Example usage
if __name__ == "__main__":
    # Replace 'your_private_key' and 'receiver_address' with appropriate values
    private_key = 'your_private_key_here'
    receiver_address = '0xabc123...'
    amount_to_send = 100

    token_name = get_token_name()
    print(f'Token Name: {token_name}')

    token_symbol = get_token_symbol()
    print(f'Token Symbol: {token_symbol}')

    token_decimals = get_token_decimals()
    print(f'Token Decimals: {token_decimals}')

    total_supply = get_token_total_supply()
    print(f'Total Token Supply: {total_supply}')

    balance = get_token_balance('your_account_address_here')
    print(f'Your Token Balance: {balance}')

    tx_hash = transfer_tokens(private_key, receiver_address, amount_to_send)
    print(f'Transaction Hash: {tx_hash}')
from web3 import Web3

# Connect to an Ethereum node (e.g., Infura)
web3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/your_infura_project_id'))

# Contract ABI (example ABI of an ERC20 token contract)
contract_abi = [
    # ... (Add the ABI entries here)
]

# Contract address (example ERC20 token contract address)
contract_address = '0x123abc...'

# Set the contract instance
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

# Example interaction with the contract (get token name)
def get_token_name():
    token_name = contract.functions.name().call()
    return token_name

# Example interaction with the contract (get token symbol)
def get_token_symbol():
    token_symbol = contract.functions.symbol().call()
    return token_symbol

# Example interaction with the contract (get token decimals)
def get_token_decimals():
    token_decimals = contract.functions.decimals().call()
    return token_decimals

# Example interaction with the contract (get token total supply)
def get_token_total_supply():
    total_supply = contract.functions.totalSupply().call()
    return total_supply

# Example interaction with the contract (get balance of an address)
def get_token_balance(account_address):
    balance = contract.functions.balanceOf(account_address).call()
    return balance

# Example transaction to transfer tokens
def transfer_tokens(sender_private_key, receiver_address, amount):
    sender_account = web3.eth.account.privateKeyToAccount(sender_private_key)
    transaction = contract.functions.transfer(receiver_address, amount).buildTransaction({
        'from': sender_account.address,
        'gas': 2000000,
        'gasPrice': web3.toWei('50', 'gwei'),
        'nonce': web3.eth.getTransactionCount(sender_account.address),
    })
    signed_txn = web3.eth.account.signTransaction(transaction, sender_private_key)
    tx_hash = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    return tx_hash.hex()

# Example usage
if __name__ == "__main__":
    # Replace 'your_private_key' and 'receiver_address' with appropriate values
    private_key = 'your_private_key_here'
    receiver_address = '0xabc123...'
    amount_to_send = 100

    token_name = get_token_name()
    print(f'Token Name: {token_name}')

    token_symbol = get_token_symbol()
    print(f'Token Symbol: {token_symbol}')

    token_decimals = get_token_decimals()
    print(f'Token Decimals: {token_decimals}')

    total_supply = get_token_total_supply()
    print(f'Total Token Supply: {total_supply}')

    balance = get_token_balance('your_account_address_here')
    print(f'Your Token Balance: {balance}')

    tx_hash = transfer_tokens(private_key, receiver_address, amount_to_send)
    print(f'Transaction Hash: {tx_hash}')
from web3 import Web3

# Connect to an Ethereum node (e.g., Infura)
web3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/your_infura_project_id'))

# Contract ABI (example ABI of an ERC20 token contract)
contract_abi = [
    # ... (Add the ABI entries here)
]

# Contract address (example ERC20 token contract address)
contract_address = '0x123abc...'

# Set the contract instance
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

# Example interaction with the contract (get token name)
def get_token_name():
    token_name = contract.functions.name().call()
    return token_name

# Example interaction with the contract (get token symbol)
def get_token_symbol():
    token_symbol = contract.functions.symbol().call()
    return token_symbol

# Example interaction with the contract (get token decimals)
def get_token_decimals():
    token_decimals = contract.functions.decimals().call()
    return token_decimals

# Example interaction with the contract (get token total supply)
def get_token_total_supply():
    total_supply = contract.functions.totalSupply().call()
    return total_supply

# Example interaction with the contract (get balance of an address)
def get_token_balance(account_address):
    balance = contract.functions.balanceOf(account_address).call()
    return balance

# Example transaction to transfer tokens
def transfer_tokens(sender_private_key, receiver_address, amount):
    sender_account = web3.eth.account.privateKeyToAccount(sender_private_key)
    transaction = contract.functions.transfer(receiver_address, amount).buildTransaction({
        'from': sender_account.address,
        'gas': 2000000,
        'gasPrice': web3.toWei('50', 'gwei'),
        'nonce': web3.eth.getTransactionCount(sender_account.address),
    })
    signed_txn = web3.eth.account.signTransaction(transaction, sender_private_key)
    tx_hash = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    return tx_hash.hex()

# Example usage
if __name__ == "__main__":
    # Replace 'your_private_key' and 'receiver_address' with appropriate values
    private_key = 'your_private_key_here'
    receiver_address = '0xabc123...'
    amount_to_send = 100

    token_name = get_token_name()
    print(f'Token Name: {token_name}')

    token_symbol = get_token_symbol()
    print(f'Token Symbol: {token_symbol}')

    token_decimals = get_token_decimals()
    print(f'Token Decimals: {token_decimals}')

    total_supply = get_token_total_supply()
    print(f'Total Token Supply: {total_supply}')

    balance = get_token_balance('your_account_address_here')
    print(f'Your Token Balance: {balance}')

    tx_hash = transfer_tokens(private_key, receiver_address, amount_to_send)
    print(f'Transaction Hash: {tx_hash}')
from web3 import Web3

# Connect to an Ethereum node (e.g., Infura)
web3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/your_infura_project_id'))

# Contract ABI (example ABI of an ERC20 token contract)
contract_abi = [
    # ... (Add the ABI entries here)
]

# Contract address (example ERC20 token contract address)
contract_address = '0x123abc...'

# Set the contract instance
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

# Get the token name from the contract
def get_token_name():
    token_name = contract.functions.name().call()
    return token_name

# Get the token symbol from the contract
def get_token_symbol():
    token_symbol = contract.functions.symbol().call()
    return token_symbol

# Get the balance of a specific Ethereum address
def get_token_balance(account_address):
    balance = contract.functions.balanceOf(account_address).call()
    return balance

# Transfer tokens to another address
def transfer_tokens(sender_private_key, receiver_address, amount):
    sender_account = web3.eth.account.privateKeyToAccount(sender_private_key)
    transaction = contract.functions.transfer(receiver_address, amount).buildTransaction({
        'from': sender_account.address,
        'gas': 2000000,
        'gasPrice': web3.toWei('50', 'gwei'),
        'nonce': web3.eth.getTransactionCount(sender_account.address),
    })
    signed_txn = web3.eth.account.signTransaction(transaction, sender_private_key)
    tx_hash = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    return tx_hash.hex()

# Get transaction details by transaction hash
def get_transaction_details(tx_hash):
    tx_details = web3.eth.getTransaction(tx_hash)
    return tx_details

# Get receipt details by transaction hash
def get_transaction_receipt(tx_hash):
    tx_receipt = web3.eth.getTransactionReceipt(tx_hash)
    return tx_receipt

# Example usage
if __name__ == "__main__":
    # Replace 'your_private_key' and 'receiver_address' with appropriate values
    private_key = 'your_private_key_here'
    receiver_address = '0xabc123...'
    amount_to_send = 100

    token_name = get_token_name()
    print(f'Token Name: {token_name}')

    token_symbol = get_token_symbol()
    print(f'Token Symbol: {token_symbol}')

    balance = get_token_balance('your_account_address_here')
    print(f'Your Token Balance: {balance}')

    tx_hash = transfer_tokens(private_key, receiver_address, amount_to_send)
    print(f'Transaction Hash: {tx_hash}')

    # Get details of the transaction
    tx_details = get_transaction_details(tx_hash)
    print(f'Transaction Details: {tx_details}')

    # Get receipt of the transaction
    tx_receipt = get_transaction_receipt(tx_hash)
    print(f'Transaction Receipt: {tx_receipt}')
from web3 import Web3

# Connect to an Ethereum node (e.g., Infura)
web3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/your_infura_project_id'))

# Contract ABI (example ABI of an ERC20 token contract)
contract_abi = [
    # ... (Add the ABI entries here)
]

# Contract address (example ERC20 token contract address)
contract_address = '0x123abc...'

# Set the contract instance
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

# Get the token name from the contract
def get_token_name():
    token_name = contract.functions.name().call()
    return token_name

# Get the token symbol from the contract
def get_token_symbol():
    token_symbol = contract.functions.symbol().call()
    return token_symbol

# Get the balance of a specific Ethereum address
def get_token_balance(account_address):
    balance = contract.functions.balanceOf(account_address).call()
    return balance

# Transfer tokens to another address
def transfer_tokens(sender_private_key, receiver_address, amount):
    sender_account = web3.eth.account.privateKeyToAccount(sender_private_key)
    transaction = contract.functions.transfer(receiver_address, amount).buildTransaction({
        'from': sender_account.address,
        'gas': 2000000,
        'gasPrice': web3.toWei('50', 'gwei'),
        'nonce': web3.eth.getTransactionCount(sender_account.address),
    })
    signed_txn = web3.eth.account.signTransaction(transaction, sender_private_key)
    tx_hash = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    return tx_hash.hex()

# Get transaction details by transaction hash
def get_transaction_details(tx_hash):
    tx_details = web3.eth.getTransaction(tx_hash)
    return tx_details

# Get receipt details by transaction hash
def get_transaction_receipt(tx_hash):
    tx_receipt = web3.eth.getTransactionReceipt(tx_hash)
    return tx_receipt

# Example usage
if __name__ == "__main__":
    # Replace 'your_private_key' and 'receiver_address' with appropriate values
    private_key = 'your_private_key_here'
    receiver_address = '0xabc123...'
    amount_to_send = 100

    token_name = get_token_name()
    print(f'Token Name: {token_name}')

    token_symbol = get_token_symbol()
    print(f'Token Symbol: {token_symbol}')

    balance = get_token_balance('your_account_address_here')
    print(f'Your Token Balance: {balance}')

    tx_hash = transfer_tokens(private_key, receiver_address, amount_to_send)
    print(f'Transaction Hash: {tx_hash}')

    # Get details of the transaction
    tx_details = get_transaction_details(tx_hash)
    print(f'Transaction Details: {tx_details}')

    # Get receipt of the transaction
    tx_receipt = get_transaction_receipt(tx_hash)
    print(f'Transaction Receipt: {tx_receipt}')
from web3 import Web3

# Connect to an Ethereum node (e.g., Infura)
web3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/your_infura_project_id'))

# Contract ABI (example ABI of an ERC20 token contract)
contract_abi = [
    # ... (Add the ABI entries here)
]

# Contract address (example ERC20 token contract address)
contract_address = '0x123abc...'

# Set the contract instance
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

# Get the token name from the contract
def get_token_name():
    token_name = contract.functions.name().call()
    return token_name

# Get the token symbol from the contract
def get_token_symbol():
    token_symbol = contract.functions.symbol().call()
    return token_symbol

# Get the balance of a specific Ethereum address
def get_token_balance(account_address):
    balance = contract.functions.balanceOf(account_address).call()
    return balance

# Transfer tokens to another address
def transfer_tokens(sender_private_key, receiver_address, amount):
    sender_account = web3.eth.account.privateKeyToAccount(sender_private_key)
    transaction = contract.functions.transfer(receiver_address, amount).buildTransaction({
        'from': sender_account.address,
        'gas': 2000000,
        'gasPrice': web3.toWei('50', 'gwei'),
        'nonce': web3.eth.getTransactionCount(sender_account.address),
    })
    signed_txn = web3.eth.account.signTransaction(transaction, sender_private_key)
    tx_hash = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    return tx_hash.hex()

# Get transaction details by transaction hash
def get_transaction_details(tx_hash):
    tx_details = web3.eth.getTransaction(tx_hash)
    return tx_details

# Get receipt details by transaction hash
def get_transaction_receipt(tx_hash):
    tx_receipt = web3.eth.getTransactionReceipt(tx_hash)
    return tx_receipt

# Example usage
if __name__ == "__main__":
    # Replace 'your_private_key' and 'receiver_address' with appropriate values
    private_key = 'your_private_key_here'
    receiver_address = '0xabc123...'
    amount_to_send = 100

    token_name = get_token_name()
    print(f'Token Name: {token_name}')

    token_symbol = get_token_symbol()
    print(f'Token Symbol: {token_symbol}')

    balance = get_token_balance('your_account_address_here')
    print(f'Your Token Balance: {balance}')

    tx_hash = transfer_tokens(private_key, receiver_address, amount_to_send)
    print(f'Transaction Hash: {tx_hash}')

    # Get details of the transaction
    tx_details = get_transaction_details(tx_hash)
    print(f'Transaction Details: {tx_details}')

    # Get receipt of the transaction
    tx_receipt = get_transaction_receipt(tx_hash)
    print(f'Transaction Receipt: {tx_receipt}')
from web3 import Web3

# Connect to an Ethereum node (e.g., Infura)
web3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/your_infura_project_id'))

# Contract ABI (example ABI of an ERC20 token contract)
contract_abi = [
    # ... (Add the ABI entries here)
]

# Contract address (example ERC20 token contract address)
contract_address = '0x123abc...'

# Set the contract instance
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

# Get the token name from the contract
def get_token_name():
    token_name = contract.functions.name().call()
    return token_name

# Get the token symbol from the contract
def get_token_symbol():
    token_symbol = contract.functions.symbol().call()
    return token_symbol

# Get the balance of a specific Ethereum address
def get_token_balance(account_address):
    balance = contract.functions.balanceOf(account_address).call()
    return balance

# Transfer tokens to another address
def transfer_tokens(sender_private_key, receiver_address, amount):
    sender_account = web3.eth.account.privateKeyToAccount(sender_private_key)
    transaction = contract.functions.transfer(receiver_address, amount).buildTransaction({
        'from': sender_account.address,
        'gas': 2000000,
        'gasPrice': web3.toWei('50', 'gwei'),
        'nonce': web3.eth.getTransactionCount(sender_account.address),
    })
    signed_txn = web3.eth.account.signTransaction(transaction, sender_private_key)
    tx_hash = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    return tx_hash.hex()

# Get transaction details by transaction hash
def get_transaction_details(tx_hash):
    tx_details = web3.eth.getTransaction(tx_hash)
    return tx_details

# Get receipt details by transaction hash
def get_transaction_receipt(tx_hash):
    tx_receipt = web3.eth.getTransactionReceipt(tx_hash)
    return tx_receipt

# Example usage
if __name__ == "__main__":
    # Replace 'your_private_key' and 'receiver_address' with appropriate values
    private_key = 'your_private_key_here'
    receiver_address = '0xabc123...'
    amount_to_send = 100

    token_name = get_token_name()
    print(f'Token Name: {token_name}')

    token_symbol = get_token_symbol()
    print(f'Token Symbol: {token_symbol}')

    balance = get_token_balance('your_account_address_here')
    print(f'Your Token Balance: {balance}')

    tx_hash = transfer_tokens(private_key, receiver_address, amount_to_send)
    print(f'Transaction Hash: {tx_hash}')

    # Get details of the transaction
    tx_details = get_transaction_details(tx_hash)
    print(f'Transaction Details: {tx_details}')

    # Get receipt of the transaction
    tx_receipt = get_transaction_receipt(tx_hash)
    print(f'Transaction Receipt: {tx_receipt}')
