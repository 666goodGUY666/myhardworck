-- This SQL file stores interactions or transactions related to web3

-- Table structure for storing web3 transactions
CREATE TABLE web3_transactions (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    transaction_hash VARCHAR(255) NOT NULL,
    sender_address VARCHAR(255) NOT NULL,
    receiver_address VARCHAR(255) NOT NULL,
    amount DECIMAL(18, 8) NOT NULL,
    transaction_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table structure for web3 user accounts
CREATE TABLE web3_accounts (
    account_id INT PRIMARY KEY AUTO_INCREMENT,
    account_address VARCHAR(255) UNIQUE NOT NULL,
    account_balance DECIMAL(18, 8) NOT NULL
);

-- Sample data for web3_accounts
INSERT INTO web3_accounts (account_address, account_balance) VALUES
('0xAddress1', 100.00),
('0xAddress2', 250.00),
('0xAddress3', 500.00);
-- Table structure for web3 transactions
CREATE TABLE web3_transactions (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    transaction_hash VARCHAR(255) NOT NULL,
    sender_address VARCHAR(255) NOT NULL,
    receiver_address VARCHAR(255) NOT NULL,
    amount DECIMAL(18, 8) NOT NULL,
    transaction_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table structure for web3 user accounts
CREATE TABLE web3_accounts (
    account_id INT PRIMARY KEY AUTO_INCREMENT,
    account_address VARCHAR(255) UNIQUE NOT NULL,
    account_balance DECIMAL(18, 8) NOT NULL
);

-- Sample data for web3_accounts
INSERT INTO web3_accounts (account_address, account_balance) VALUES
('0xAddress1', 100.00),
('0xAddress2', 250.00),
('0xAddress3', 500.00);

-- Adding a new transaction
INSERT INTO web3_transactions (transaction_hash, sender_address, receiver_address, amount)
VALUES ('0xTransactionHash1', '0xSenderAddress', '0xReceiverAddress', 50.00);

-- Updating account balance after a transaction
UPDATE web3_accounts
SET account_balance = account_balance - 50.00
WHERE account_address = '0xSenderAddress';

UPDATE web3_accounts
SET account_balance = account_balance + 50.00
WHERE account_address = '0xReceiverAddress';
-- This SQL file stores interactions or transactions related to web3

-- Table structure for storing web3 transactions
CREATE TABLE web3_transactions (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    transaction_hash VARCHAR(255) NOT NULL,
    sender_address VARCHAR(255) NOT NULL,
    receiver_address VARCHAR(255) NOT NULL,
    amount DECIMAL(18, 8) NOT NULL,
    transaction_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table structure for web3 user accounts
CREATE TABLE web3_accounts (
    account_id INT PRIMARY KEY AUTO_INCREMENT,
    account_address VARCHAR(255) UNIQUE NOT NULL,
    account_balance DECIMAL(18, 8) NOT NULL
);

-- Sample data for web3_accounts
INSERT INTO web3_accounts (account_address, account_balance) VALUES
('0xAddress1', 100.00),
('0xAddress2', 250.00),
('0xAddress3', 500.00);

-- Additional transactions
INSERT INTO web3_transactions (transaction_hash, sender_address, receiver_address, amount)
VALUES
('0xTransactionHash1', '0xAddress2', '0xAddress1', 50.00),
('0xTransactionHash2', '0xAddress3', '0xAddress1', 100.00),
('0xTransactionHash3', '0xAddress1', '0xAddress2', 30.00);

-- More sample data for accounts
INSERT INTO web3_accounts (account_address, account_balance) VALUES
('0xAddress4', 300.00),
('0xAddress5', 700.00),
('0
